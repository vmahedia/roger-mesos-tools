## Roger CLI

A Vagrant VM + tools/scripts to interact with [RogerOS](https://github.com/seomoz/roger) via the command line.

## The roger-cli.local vagrant VM

The vagrant VM is set up with packages and environment needed to connect to the cluster os and run various roger-cli commands.

### Pre-requisites
* ```virtualbox```
* ```vagrant``` along with the following plugins (install from the command line as below):
```
$ vagrant plugin install vagrant-hostsupdater # https://github.com/cogitatio/vagrant-hostsupdater
$ vagrant plugin install vagrant-triggers # https://github.com/emyl/vagrant-triggers
```

### How to get started
1. git clone this repo into your working directory
2. Run: `$ vagrant up && vagrant ssh`
3. You will need to to enable ssh forwarding in the host machine if you need to access git or ssh to machines from within the VM. Some details on how to do this are on the screen after vagrant up:
  * Run ```ssh-add <path to ssh key to use for ssh forwarding>``` on the HOST for ssh forwarding to work.
  * Run ```git config --global user.name <your name>``` on the vagrant VM.
4. If you already have a project config file and in roger/tools/config (and 1 or more application template files) then skip to the next step else:
  * Initialize your application: `$ roger init <app_name> <project_name>`
  * This will create a project config file in `$ROGER_CONFIG_DIR` (set to `/vagrant/config`) and a template file in `$ROGER_TEMPLATES_DIR` (set to `/vagrant/template`) directory in the VM. Some more details on these are other environment variables are provided later below.
  * Note that in the roger-cli VM /vagrant is really the directory on the host machine from where you ran `vagrant up` & `vagrant ssh`. Any changes made in the host directory will be reflected in the VM as well. So if you modify any file in the home directory , you can test the changes directly in the VM. ( We do not need to quit and "vagrant up && vagrant ssh" again, since its the common directory.)
  * So, these files are really new files in the git directory you cloned above. You should create a pull request to get this merged.
5. Now that you have a project config file and 1 (or more) application templates, you can add more applications to the config file along with a new application template for each application. Adding an application requires:
  * A new entry in the project config file. The config file contains
    * repo location for each of the applications
    * common variables and settings for the applications
    * application specific as well as environment specific variables
    * (and more...)
  * A new application template for the new entry above. The template file is used to create the actual application configuration that is sent to the mesos framework.
  * At this point you should make appropriate changes to the files (refer to existing files if required.)
6. Now we're ready to **deploy to RogerOS**.
  * The easiest way to deploy your code to Roger OS is
  * `$ roger deploy <app name> <config file>`
  * This will pull the latest code from master, build (docker build) your app, give it an appropriate name/version before pushing it to the docker registry and also deploy it to RogerOS.
  * Try ```roger deploy -h``` for details on more options.
  * ```roger``` is a cli to work with roger os
7. If you prefer to work on the VM and need more control over the process, you could also **pull from git, build, push to Roger** manually.
  * To pull your git repo into a working directory use:
  * `$ roger git-pull <app name> <working directory> <config file>`
  * To build the latest code in this working directory:
  * `$ roger bulid <app name> <working directory> <tag name> <config file>`
  * To push the image (tag) above to Roger OS:
  * `$ roger push <app name> <working directory> <tag name> <config file>`
8. To get interactive shell access to any of your containers running on Roger OS you can:
  * `$ roger shell <mesos task id>`
9. For all of these commands try `roger <command> -h` for more options.

## Things to know

#### Environment variables
The required environment variables are already set in the CLI VM.

1. ROGER_CONFIG_DIR.
  * The directory where the team config files should be.
  * On the VM this is set to `/vagrant/config`.
  * You should NOT change this usually.
2. ROGER_TEMPLATES_DIR.
  * The directory where the framework template file should be.
  * On the VM this is set to `/vagrant/templates`.
  * You should NOT change this usually.
3. ROGER_COMPONENTS_DIR.
  * The directory where the generated (rendered) framework config file is placed (after roger-deploy or roger-push).
  * On the VM this is set to `/home/vagrant/roger-cli/components`.
  * You can change this as per your needs.
4. ROGER_SECRETS_DIR.
  * The directory where secret environment variables config file should be.
  * On the VM this is set to `/home/vagrant/roger-cli/secrets`.
  * You can change this as per your needs.

### Variables

1. Variables can be added to the project config file.
2. Sample use of them have been provided in the sample_config.json here: [config/sample_config.json](config/sample_config.json)
3. There is support for 4 types of variables now which are as follows:
4. a) Global variables that apply to all applications
5. b) Environment variables that apply to all applications. There values are determined based on which env is provided (dev,stage or prod).
6. c) Global variables applied to a specific application.
7. d) Environment variables applied to a specific application. There values are determined based on which env is provided (dev,stage or prod).
8. For a variable occurring in multiple sections,the precedence order is: d > c > b > a.
9. A sample marathon json file using variables has been added in this directory: [templates](templates)

#### Example

Let us consider an example to understand the variables assignment to a specific application.

The default environment is "dev". We can also specify the environment as a parameter to "roger push" command as :

* `$ roger push [-e <env_name>] app_name directory image_name config_file`

Let us consider the sample app configuration which is in the config file

```
"apps": {
  "container-vars": {
    "name": "container-vars",
    "containers": [
      {"tests" : {"vars": {
                             "global": {
                                              "VAR1":  "value_1",
                                              "VAR2":  "value_2",
                                              "VAR3":  "value_3",
                                              "VAR4":  "value_4"
                                        },

                             "environment": {
                                              "dev":     { "VAR1":      "environment_value_1"},
                                              "prod":    { "VAR4":      "environment_value_4"}
                                              "own_env": { "VAR_OWN":   "own_value" }
                                            }
                            }
                   }
      }
    ]
  }
```
### Scenario 1:

When we do an roger push using the above config file , with the default ( dev ) environment. The variables VAR1 value is overridden to "environment_value_1". The rest of the
variables retain there values from "global".

* `$ roger push app_name directory image_name config_file`

So the values which gets pushed to "dev" environment are :

"VAR1":  "environment_value_1",
"VAR2":  "value_2",
"VAR3":  "value_3",
"VAR4":  "value_4"

### Scenario 2

Now if we use roger push with environment as "stage" , since there is no stage environment in the app file , all the values which are set in "global" takes effect.

* `$ roger push -e stage app_name directory image_name config_file`

"VAR1":  "value_1",
"VAR2":  "value_2",
"VAR3":  "value_3",
"VAR4":  "value_4"

### Scenario 3

You can also add new variables which are not a part of global. Let us consider , we use roger push , with the parameter "own_env". Then along with all the 4 variables provided
in global , the new variable "VAR_OWN" also gets pushed. So the values which gets pushed are:

* `$ roger push -e own_env app_name directory image_name config_file`

"VAR1":    "value_1",
"VAR2":    "value_2",
"VAR3":    "value_3",
"VAR4":    "value_4"
"VAR_OWN": "own_value"

#### Roger-Push Architecture
  ![Architecture](roger-cli.png)

### More info
More information on the scripts can be found [here](bin/README.md).



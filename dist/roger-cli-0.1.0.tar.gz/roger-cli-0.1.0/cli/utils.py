#!/usr/bin/python

from __future__ import print_function
import os
import sys

class Utils:

  # Expected format:
  #   moz-content-kairos-7da406eb9e8937875e0548ae1149/v0.46
  def extractFullShaAndVersion(self, image):
    if not '-' in image:
      return ''
    tokens = image.split('-')
    if len(tokens) != 0:
      return tokens[-1]
    else:
      return ''

  # Expected format:
  #   moz-content-kairos-7da406eb9e8937875e0548ae1149/v0.46
  def extractShaFromImage(self, image):
    if not '/v' in image:
      return ''
    sha = image.split('/v')
    if len(sha) != 0:
      sha = sha[0].split('-')
      if len(sha) != 0:
        return sha[-1]
    return ''

